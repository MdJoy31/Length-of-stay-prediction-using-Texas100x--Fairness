# CHRONO-Fair: code and data (local run bundle)

This folder contains the runnable CHRONO-Fair prototype and its data.
The Python package lives in `chrono_fair/`. Run everything from THIS
top-level folder so that `import chrono_fair...` resolves.

## 1. Install dependencies

    python -m venv .venv && source .venv/bin/activate
    pip install -r chrono_fair/requirements.txt

## 2. Run the unit tests (should be 12 passed)

    python -m pytest chrono_fair/tests/ -q

## 3. End-to-end live-monitoring verification (11/11 checks)

    python -m chrono_fair.verify_end_to_end

## 4. Two-process live demo (append CSV rows -> scores update)

    # Terminal A: append a 200-row batch every 2s, drift after row 3000
    python -m chrono_fair.live_demo produce --csv /tmp/feed.csv \
        --interval 2 --batch 200 --drift-after 3000

    # Terminal B: tail the CSV and print live per-cell scores + alarms
    python -m chrono_fair.live_demo monitor --csv /tmp/feed.csv \
        --attr race --rho0 0.05 --alpha 0.05

## 5. Streamlit dashboard

    pip install streamlit plotly
    streamlit run chrono_fair/app.py

## 6. Reproduce the paper experiments (writes ../chrono_fair_figures/)

    python -m chrono_fair.experiments.exp1_detection_delay
    python -m chrono_fair.experiments.exp8_real_vfr_analysis
    # ... exp1 .. exp18

## Data included

- `chrono_fair/data/texas100x_synthetic_stream.csv` : full synthetic stream
- `chrono_fair/data/splits/` : train / val / test splits
- `chrono_fair/data/texas100_real_subsample.npz` : real Texas-100 subsample
- `chrono_fair/data/real_texas100x_audit_artifacts.json` : real audit outputs
- `chrono_fair/data/DATA_CARD.md` : data provenance and schema

Research prototype. Not a medical device. Streaming is controlled replay
and simulation, not a live clinical feed.
